### Hexlet tests and linter status:
[![Actions Status](https://github.com/mtalipowa/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/mtalipowa/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/c58cfcdc387e265740da/maintainability)](https://codeclimate.com/github/mtalipowa/python-project-49/maintainability)
### Brain-even and install
[![asciicast](https://asciinema.org/a/crscVEOw0iVOOmwxGRR7H7xYM.svg)](https://asciinema.org/a/crscVEOw0iVOOmwxGRR7H7xYM)
### Brain-calc
[![asciicast](https://asciinema.org/a/h4AraOcXPE0oiTYiMf7gi60OI.svg)](https://asciinema.org/a/h4AraOcXPE0oiTYiMf7gi60OI)
### Brain-gcd
[![asciicast](https://asciinema.org/a/DBQLYBc23CPvDiRfujeWkwQdl.svg)](https://asciinema.org/a/DBQLYBc23CPvDiRfujeWkwQdl)
### Brain-progression
[![asciicast](https://asciinema.org/a/AfvB7HUoziefY1ZhLbFyHLgS4.svg)](https://asciinema.org/a/AfvB7HUoziefY1ZhLbFyHLgS4)
### Brain-prime
[![asciicast](https://asciinema.org/a/sLH3GBTWQoSGTecLDfNjbidJ0.svg)](https://asciinema.org/a/sLH3GBTWQoSGTecLDfNjbidJ0)
